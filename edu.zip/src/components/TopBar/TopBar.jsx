import React  from "react";
import styled from "styled-components";
import Container from "../../components/Container"
import { NavLink,useNavigate } from 'react-router-dom'
import AuthContext from "../../contexts/Auth"


const TopBar = () => {
//const checkAuthRegister= useContext(AuthContext);
const navigate = useNavigate();
const handleRegister=()=>{
  localStorage.removeItem('accessToken')
  navigate('/register')
}

    return (
      <StyledWrapper>
        <Container>
        <StyledBottom>
        <StyledLogo>
        Edu<span>Le</span>
        </StyledLogo>
        <StyleMenu>
    <StyledItems>
      <StyledItem>
        <StyledLink to="#">
       Home   
        </StyledLink>
      </StyledItem>
      <StyledItem>
        <StyledLink to="#">
        All Cource    
        </StyledLink>
      </StyledItem>
      <StyledItem>
        <StyledLink to="#">
        Pages  
        </StyledLink>
      </StyledItem>
      <StyledItem>
        <StyledLink to="#">
        Blog
        </StyledLink>
      </StyledItem>
      <StyledItem>
        <StyledLink to="#">
        Contact
        </StyledLink>
      </StyledItem>
    </StyledItems>
    </StyleMenu>
    <StyledAuth>
    <StyledItems>
    <StyledItem>
    <StyledLink to="#">
       Sign In  
        </StyledLink>
        </StyledItem>
        <StyledItem onClick={handleRegister}>
       Sign Up 
        </StyledItem>
        </StyledItems>
    </StyledAuth>
        </StyledBottom>
        </Container>
        </StyledWrapper>
    )
}

const StyledWrapper= styled.div`
position: absolute;
width: 100%;
`
const StyledBottom= styled.header`
border-radius:${(props) => props.theme.radius.RadiusOne};
display:flex;
border: 3px solid #def3e7;
padding: 10px;
margin-top: 18px;
border-radius: 5px;
`
const StyledLogo= styled.div`
font-family: "PlayfairBold";
    font-size: 1.8rem;
span{
  color:${(props) => props.theme.color.ColorThree};
}
`
const StyleMenu= styled.div`
flex: 1 0 0;
display: flex;
justify-content: center;
`
const StyledItems = styled.ul`
display:flex;
flex-wrap:wrap;
justify-content:space-between;
fond-size:1.1rem;
`
const StyledItem = styled.li`
min-width: 85px;
text-align: center;
font-size: 1rem;
padding: 11px 20px;
`
const StyledLink = styled(NavLink)`
color:${(props) => props.theme.color.ColorOne};
font-weight: bold;
`
const StyledAuth = styled.div`
ul{
  li{
    &:last-child{
      border-radius:${(props) => props.theme.radius.RadiusOne};
      background: rgba(255,255,255,0.8);
      border: 3px solid #def3e7;
    }
  }
}
`
export default TopBar;