/*text*/export const ColorOne = '#273443'
/*text*/export const ColorTwo = '#ffffff'
/*bg*/export const ColorThree = '#529356'
/*bg*/export const ColorFour = '#e7f8ee'

export const RadiusOne = '7px'







