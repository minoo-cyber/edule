import React, { useEffect, useRef, useState} from "react";
import AuthContext from "./AuthContext"

  const AuthState = ({ children }) => {
   const [accessToken,setAccessToken]=useState()


   useEffect(()=>{
    if (accessToken) {
      localStorage.setItem('accessToken', accessToken)
  }


   },[accessToken])
  
        return (
          <AuthContext.Provider value={{accessToken,setAccessToken}}>
            { children }
            </AuthContext.Provider>
        );
    }


export default AuthState;
